using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace EditorGraficasVectoriales
{
    public partial class FrmEditor : Form
    {
        private Point puntoInicial;
        private Point puntoFinal;
        private bool dibujando = false;
        private bool modoDibujoActivo = false;
        private List<(int tipo, Rectangle rect)> figuras = new List<(int, Rectangle)>();
        private Rectangle? figuraSeleccionada = null;

        public FrmEditor()
        {
            InitializeComponent();
            cmbTrazo.SelectedIndex = 0;
            btnBorrar.Click += btnBorrar_Click;
            btnLimpiar.Click += btnLimpiar_Click;
            btnSeleccionar.Click += btnSeleccionar_Click;
            btnGuardar.Click += btnGuardar_Click;
            btnAbrir.Click += btnAbrir_Click;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog saveDialog = new SaveFileDialog())
            {
                saveDialog.Filter = "JSON Files|*.json";
                saveDialog.Title = "Guardar Proyecto";
                saveDialog.FileName = "Proyecto";

                if (saveDialog.ShowDialog() == DialogResult.OK)
                {
                    string json = JsonConvert.SerializeObject(figuras);
                    File.WriteAllText(saveDialog.FileName, json);
                    MessageBox.Show("Proyecto guardado exitosamente.", "Guardar", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void btnAbrir_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openDialog = new OpenFileDialog())
            {
                openDialog.Filter = "JSON Files|*.json";
                openDialog.Title = "Abrir Proyecto";

                if (openDialog.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        string json = File.ReadAllText(openDialog.FileName);
                        figuras = JsonConvert.DeserializeObject<List<(int tipo, Rectangle rect)>>(json);

                        if (figuras == null)
                        {
                            MessageBox.Show("El archivo est� vac�o o tiene un formato incorrecto.", "Error al abrir", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else
                        {
                            pnlDibujo.Invalidate();
                            MessageBox.Show("Proyecto abierto exitosamente.", "Abrir", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    catch (JsonException ex)
                    {
                        MessageBox.Show($"Error al leer el archivo JSON: {ex.Message}", "Error de JSON", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error al abrir el proyecto: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void pnlDibujo_MouseDown(object sender, MouseEventArgs e)
        {
            if (modoDibujoActivo && e.Button == MouseButtons.Left)
            {
                puntoInicial = e.Location;
                dibujando = true;
            }
            else if (btnSeleccionar.Enabled)
            {
                figuraSeleccionada = figuras
                    .Where(f => f.rect.Contains(e.Location))
                    .Select(f => f.rect)
                    .FirstOrDefault();
                pnlDibujo.Invalidate();
            }
        }

        private void pnlDibujo_MouseMove(object sender, MouseEventArgs e)
        {
            if (dibujando)
            {
                puntoFinal = e.Location;
                pnlDibujo.Invalidate();
            }
        }

        private void pnlDibujo_MouseUp(object sender, MouseEventArgs e)
        {
            if (dibujando)
            {
                dibujando = false;
                puntoFinal = e.Location;
                Rectangle figura = GetRectangle(puntoInicial, puntoFinal);
                figuras.Add((cmbTrazo.SelectedIndex, figura));
                pnlDibujo.Invalidate();
            }
        }

        private void pnlDibujo_Paint(object sender, PaintEventArgs e)
        {
            using (Pen pen = new Pen(Color.White, 2))
            {
                foreach (var (tipo, rect) in figuras)
                {
                    if (figuraSeleccionada.HasValue && rect == figuraSeleccionada.Value)
                    {
                        pen.Color = Color.Red;
                    }
                    else
                    {
                        pen.Color = Color.White;
                    }

                    switch (tipo)
                    {
                        case 0:
                            e.Graphics.DrawLine(pen, rect.Location, new Point(rect.Right, rect.Bottom));
                            break;
                        case 1:
                            e.Graphics.DrawRectangle(pen, rect);
                            break;
                        case 2:
                            e.Graphics.DrawEllipse(pen, rect);
                            break;
                    }
                }

                if (dibujando)
                {
                    switch (cmbTrazo.SelectedIndex)
                    {
                        case 0:
                            e.Graphics.DrawLine(pen, puntoInicial, puntoFinal);
                            break;
                        case 1:
                            e.Graphics.DrawRectangle(pen, GetRectangle(puntoInicial, puntoFinal));
                            break;
                        case 2:
                            e.Graphics.DrawEllipse(pen, GetRectangle(puntoInicial, puntoFinal));
                            break;
                    }
                }
            }
        }

        private void btnDibujar_Click(object sender, EventArgs e)
        {
            modoDibujoActivo = !modoDibujoActivo;
            btnDibujar.BackColor = modoDibujoActivo ? Color.LightGray : Color.Transparent;
        }

        private Rectangle GetRectangle(Point p1, Point p2)
        {
            return new Rectangle(
                Math.Min(p1.X, p2.X),
                Math.Min(p1.Y, p2.Y),
                Math.Abs(p2.X - p1.X),
                Math.Abs(p2.Y - p1.Y));
        }

        private void btnBorrar_Click(object sender, EventArgs e)
        {
            if (figuraSeleccionada.HasValue)
            {
                figuras.RemoveAll(f => f.rect == figuraSeleccionada.Value);
                figuraSeleccionada = null;
                pnlDibujo.Invalidate();
            }
            else
            {
                MessageBox.Show("Primero seleccione una figura para eliminar.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            figuras.Clear();
            pnlDibujo.Invalidate();
            using (Graphics g = pnlDibujo.CreateGraphics())
            {
                g.Clear(pnlDibujo.BackColor);
            }
        }

        private void btnSeleccionar_Click(object sender, EventArgs e)
        {
            btnSeleccionar.BackColor = btnSeleccionar.BackColor == Color.Transparent ? Color.LightGray : Color.Transparent;
        }
    }
}
